pdf.js (pdfjs-dist 6.4.299, сборка legacy — работает и в браузерах постарше; Mozilla, Apache-2.0) — без изменений
